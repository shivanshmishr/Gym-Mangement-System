import React from 'react';
import PropTypes from 'prop-types';
import './ViewHistory.css';

const ViewHistory = () => (
  <div className="ViewHistory">
    ViewHistory Component
  </div>
);

ViewHistory.propTypes = {};

ViewHistory.defaultProps = {};

export default ViewHistory;
