import React from 'react';
import PropTypes from 'prop-types';
import './EditHistory.css';

const EditHistory = () => (
  <div className="EditHistory">
    EditHistory Component
  </div>
);

EditHistory.propTypes = {};

EditHistory.defaultProps = {};

export default EditHistory;
