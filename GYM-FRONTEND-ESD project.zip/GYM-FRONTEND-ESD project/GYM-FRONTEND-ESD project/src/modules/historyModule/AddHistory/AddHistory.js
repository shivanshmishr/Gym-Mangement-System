import React from 'react';
import PropTypes from 'prop-types';
import './AddHistory.css';

const AddHistory = () => (
  <div className="AddHistory">
    AddHistory Component
  </div>
);

AddHistory.propTypes = {};

AddHistory.defaultProps = {};

export default AddHistory;
