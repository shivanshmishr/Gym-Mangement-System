import React from 'react';
import PropTypes from 'prop-types';
import './ViewBooking.css';

const ViewBooking = () => (
  <div className="ViewBooking">
    ViewBooking Component
  </div>
);

ViewBooking.propTypes = {};

ViewBooking.defaultProps = {};

export default ViewBooking;
