import React from 'react';
import PropTypes from 'prop-types';
import './AddUser.css';

const AddUser = () => (
  <div className="AddUser">
    AddUser Component
  </div>
);

AddUser.propTypes = {};

AddUser.defaultProps = {};

export default AddUser;
