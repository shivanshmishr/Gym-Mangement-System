import React from 'react';
import PropTypes from 'prop-types';
import './EditUser.css';

const EditUser = () => (
  <div className="EditUser">
    EditUser Component
  </div>
);

EditUser.propTypes = {};

EditUser.defaultProps = {};

export default EditUser;
