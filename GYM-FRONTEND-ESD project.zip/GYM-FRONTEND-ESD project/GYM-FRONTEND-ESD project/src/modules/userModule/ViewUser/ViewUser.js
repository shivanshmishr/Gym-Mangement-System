import React from 'react';
import PropTypes from 'prop-types';
import './ViewUser.css';

const ViewUser = () => (
  <div className="ViewUser">
    ViewUser Component
  </div>
);

ViewUser.propTypes = {};

ViewUser.defaultProps = {};

export default ViewUser;
