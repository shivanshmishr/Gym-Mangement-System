import React from 'react';
import PropTypes from 'prop-types';
import './ViewActivity.css';

const ViewActivity = () => (
  <div className="ViewActivity">
    ViewActivity Component
  </div>
);

ViewActivity.propTypes = {};

ViewActivity.defaultProps = {};

export default ViewActivity;
