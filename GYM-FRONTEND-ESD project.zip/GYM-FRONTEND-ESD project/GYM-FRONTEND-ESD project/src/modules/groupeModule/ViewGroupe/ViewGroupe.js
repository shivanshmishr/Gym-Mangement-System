import React from 'react';
import PropTypes from 'prop-types';
import './ViewGroupe.css';

const ViewGroupe = () => (
  <div className="ViewGroupe">
    ViewGroupe Component
  </div>
);

ViewGroupe.propTypes = {};

ViewGroupe.defaultProps = {};

export default ViewGroupe;
