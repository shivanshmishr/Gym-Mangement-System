import React from 'react';
import PropTypes from 'prop-types';
import './EditCourse.css';

const EditCourse = () => (
  <div className="EditCourse">
    EditCourse Component
  </div>
);

EditCourse.propTypes = {};

EditCourse.defaultProps = {};

export default EditCourse;
