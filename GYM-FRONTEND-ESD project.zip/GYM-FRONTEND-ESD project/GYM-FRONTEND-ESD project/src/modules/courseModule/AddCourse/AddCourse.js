import React from 'react';
import PropTypes from 'prop-types';
import './AddCourse.css';

const AddCourse = () => (
  <div className="AddCourse">
    AddCourse Component
  </div>
);

AddCourse.propTypes = {};

AddCourse.defaultProps = {};

export default AddCourse;
