import React from 'react';
import PropTypes from 'prop-types';
import './ViewCourse.css';

const ViewCourse = () => (
  <div className="ViewCourse">
    ViewCourse Component
  </div>
);

ViewCourse.propTypes = {};

ViewCourse.defaultProps = {};

export default ViewCourse;
