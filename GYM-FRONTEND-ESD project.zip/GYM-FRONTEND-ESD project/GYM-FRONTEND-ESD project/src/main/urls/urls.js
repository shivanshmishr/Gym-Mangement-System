const BASE_URL = 'https://gym-client.herokuapp.com'

export default BASE_URL
