export const HTTP_ERR_MESSAGE = "The server encountered an error processing the request.Please try again, Sorry for the trouble."

