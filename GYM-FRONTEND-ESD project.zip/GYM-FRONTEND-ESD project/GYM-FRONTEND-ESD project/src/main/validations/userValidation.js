
const userValidation = { post: 'le poste doit etre definie' }
export default userValidation;