
const revenueValidation = {
    name: 'Income name is required',
    amount: 'Amount is required',
    date: 'Date is required',
}
export default revenueValidation;