
const bookingValidation = { post: 'le poste doit etre definie' }
export default bookingValidation;