
const exerciceValidation = {
    member_id: 'Membre doit etre definie',
    record_date: 'Date doit etre definie',
}
export default exerciceValidation;