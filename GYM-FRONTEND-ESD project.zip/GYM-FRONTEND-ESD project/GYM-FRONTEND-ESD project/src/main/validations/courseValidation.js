
const courseValidation = { category: 'Categorie doit etre definie' }
export default courseValidation;